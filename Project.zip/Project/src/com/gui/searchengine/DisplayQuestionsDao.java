package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class DisplayQuestionsDao {
	
	static boolean success=false;
    private static Questions questions=null;
    public static ArrayList<Object> list=new ArrayList<>();
    
private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
	}
public static ArrayList<Object>  search() throws ClassNotFoundException, SQLException{
		StringBuilder sql = new StringBuilder("select * from "+FetchExamSchedule.examNameFromDB);
		Connection con = null;
		
		PreparedStatement pstmt = null;
	    ResultSet rs = null;
	
		boolean isFound = false;
		try
		{
			con = createConnection();
			list.clear();			
			
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
						
		    while(rs.next()){
				isFound = true;
							
				success=true;	
				questions=new Questions();
				
				questions.setId(rs.getInt("id"));
				questions.setQuestions(rs.getString("question"));
				questions.setOne(rs.getString("one"));
				questions.setTwo(rs.getString("two"));
				questions.setThree(rs.getString("three"));
				questions.setFour(rs.getString("four"));
				questions.setResult(rs.getString("result"));
				list.add(questions);
							
		    }
			if(!isFound){
				success=false;
			}
			
	}
		finally{
			if(rs!=null){
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
				}
				if(con!=null){
				con.close();
				}
		}
		return list;
	}
}
