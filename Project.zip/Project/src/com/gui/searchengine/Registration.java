package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Registration extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textField4;
	private double id;
	private String name;
	private String email;
	private String password;
	private String country;
	private int counter;
	private JButton btnNewButton=null;
	private JTextField textField;
	private JPasswordField textField3;
    private JLabel img;
    private JLabel lblNewLabel;
	
		
	public Registration() {
		
		Icon icon=new ImageIcon(Registration.class.getResource("loading.gif"));
		
		
		setResizable(false);
		getContentPane().setForeground(Color.CYAN);
		setForeground(Color.GRAY);
		getContentPane().setFont(new Font("Arial Black", Font.BOLD, 15));
		setFont(new Font("Arial Black", Font.BOLD, 15));
		setTitle("Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 478, 415);
		getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblName.setBounds(10, 83, 68, 22);
		getContentPane().add(lblName);
		
		textField1 = new JTextField();
		textField1.setToolTipText("Enter Name");
		textField1.setBounds(135, 87, 206, 20);
		getContentPane().add(textField1);
		textField1.setColumns(10);
		

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblEmail.setBounds(10, 137, 82, 14);
		getContentPane().add(lblEmail);
		
		textField2 = new JTextField();
		textField2.setBounds(135, 137, 206, 20);
		textField2.setToolTipText("Enter Email");
		getContentPane().add(textField2);
		textField2.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblPassword.setBounds(10, 193, 96, 14);
		getContentPane().add(lblPassword);
		
		JLabel lblCountry = new JLabel("Country");
		lblCountry.setFont(new Font("Arial Black", Font.BOLD, 16));
		
		lblCountry.setBounds(10, 238, 96, 22);
		getContentPane().add(lblCountry);
		
		textField4 = new JTextField();
		textField4.setBounds(135, 242, 206, 20);
		textField4.setToolTipText("Enter Country Name");
		getContentPane().add(textField4);
		textField4.setColumns(10);
		
		btnNewButton = new JButton("Submit");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				validationCheck();
				if(counter>=5)
				{
				    new RegisterDao();
					
              	try
              	{
              					
              		RegisterDao.insert(id, name, email, password, country);
              	 
              	
              	}
              	catch (ClassNotFoundException | SQLException e1 ) {
						e1.printStackTrace();
					}
              	    setVisible(false);
              	    	
				}
				else {
					JOptionPane.showMessageDialog(textField, " Enter Empty Field ", "EMPTY FIELD ", counter);
					textField.setText("");
					textField1.setText("");
					textField2.setText("");
					textField3.setText("");
					textField4.setText("");
					
				}
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnNewButton.setBounds(316, 303, 104, 31);
		getContentPane().add(btnNewButton);
		
		JLabel lblRegNoid = new JLabel("Reg. No/ID");
		lblRegNoid.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblRegNoid.setBounds(10, 39, 117, 22);
		getContentPane().add(lblRegNoid);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				img.setIcon(icon);
				img.setText("");
			}
		});
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				
				if(textField.getText().indexOf("a")>=0)
				{
					img.setText("not valid");
					System.out.println("not valid");
				}	
		else{
			   System.out.println("valid");
				double id;
				id =Integer.parseInt(textField.getText());
						
			try
		 {
				boolean status=	IdVerifyDAO.insert(id);
				if(status)
				{
					img.setIcon(null);
					img.setText("");
					img.setText("Already Exists");
				}
				else
				{
				
					img.setVisible(false);
					img.setText("");
				}
			} 
			   catch (ClassNotFoundException e1)
			{
				  
						e1.printStackTrace();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
		}	
		     });
			
		textField.setBounds(135, 42, 206, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField3 = new JPasswordField();
		textField3.setToolTipText("Enter Password");
		textField3.setBounds(135, 193, 206, 20);
		getContentPane().add(textField3);
		
		JButton btnNewButton2 = new JButton("Already Register");
		btnNewButton2.setForeground(Color.BLUE);
		btnNewButton2.setFont(new Font("Arial Black", Font.BOLD, 13));
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
							
              	    setVisible(false);
              	    
					Login loginframe = new Login();	
					loginframe.setVisible(true);
		}
		
		});
		btnNewButton2.setBounds(51, 305, 180, 28);
		getContentPane().add(btnNewButton2);
		
		img = new JLabel("");
		img.setFont(new Font("Arial Black", Font.BOLD, 10));
		img.setBounds(351, 39, 111, 28);
		getContentPane().add(img);
		
		lblNewLabel = new JLabel("Registration:");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 0, 117, 22);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("*  Userid and Password must be 6 digits. ");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(10, 361, 410, 14);
		getContentPane().add(lblNewLabel_1);
		
	}
		
	
@SuppressWarnings("deprecation")
private void validationCheck() {
	try{
	
		if(textField.getText().length()==6)
	{
		id=Double.parseDouble(textField.getText());
		
			counter++;
		
	}	
		else{
			textField.setText("Id is not Valid" );
		}
				
		name=textField1.getText();
		if(name.isEmpty()&&name.indexOf("1")>0){
			textField1.setText("Name not be Valid" );
		}
		else{
			counter++;
		}
				
		email = textField2.getText();
			if(email.isEmpty()){
				textField2.setText("email empty");
			}
			else if(email.toLowerCase().indexOf("a")>=0 && (email.toLowerCase().endsWith(".com")||email.toLowerCase().endsWith(".in")) || (email.toLowerCase().contains("yahoo")||email.toLowerCase().contains("gmail") || (email.toLowerCase().contains("@")) ))
			{
				counter++;
			}
			else
			{
				textField2.setText("");
				textField2.setText("invalid email");
		}
			
	     password = textField3.getText();	
	    
	     
		if(password.isEmpty()){
			textField3.setText("Password can not be blank");
		}
		else if(password.length()==6){
			counter++;
		}
		else {
            textField3.setText("");
            JOptionPane.showMessageDialog(this,"maximum 6 characters in PASSWORD");
		}
		
		country = textField4.getText();
		if(country.isEmpty()){
			textField4.setText("");
		}
		else
		{
		counter++;
		}
}
		catch(Exception e){
			textField1.setText("Enter Name");
			textField2.setText("Enter Email");
			textField3.setText("Enter Password");
			textField4.setText("Enter Country");
			 e.printStackTrace();
		}
	}
}