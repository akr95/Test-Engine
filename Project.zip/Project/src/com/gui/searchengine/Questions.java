package com.gui.searchengine;

public class Questions {
 
	private int id;
	private  String questions;
	private  String one;
	private  String two;
	private  String three;
	private  String four;
	private  String result;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestions() {
		return questions;
	}
	public void setQuestions(String questions) {
		this.questions = questions;
	}
	public String getOne() {
		return one;
	}
	public void setOne(String one) {
		this.one = one;
	}
	public String getTwo() {
		return two;
	}
	public void setTwo(String two) {
		this.two = two;
	}
	public String getThree() {
		return three;
	}
	public void setThree(String three) {
		this.three = three;
	}
	public String getFour() {
		return four;
	}
	public void setFour(String four) {
		this.four = four;
	}
	
	@Override
	public String toString() {
		return "Questions [id=" + id + ", questions=" + questions + ", one="
				+ one + ", two=" + two + ", three=" + three + ", four=" + four
				+ "]";
	}
	
	
}
