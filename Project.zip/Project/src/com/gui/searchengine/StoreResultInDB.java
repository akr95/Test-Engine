package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class StoreResultInDB 
{
     
    static Connection createConnection() throws SQLException, ClassNotFoundException
    {
    	ResourceBundle rb = ResourceBundle.getBundle("path");
	Class.forName(rb.getString("drivername"));
	Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
	return con;
    }
    
    static void insert(double userid,double marks ,String subject) throws ClassNotFoundException, SQLException
    {
    	Connection con=null;
    	PreparedStatement pstmt=null;
    	int recordedAdded=0;
    	
    	StringBuilder sb=new StringBuilder("insert into examresult (userid,marks,subject) values(?,?,?)");
    try{	
    	con=createConnection();
    	pstmt=con.prepareStatement(sb.toString());
    	pstmt.setDouble(1, userid);
    	pstmt.setDouble(2, marks);
		pstmt.setString(3, subject);
    	recordedAdded=pstmt.executeUpdate();  
    	if(recordedAdded>0)
    	{
    		System.out.println("add result in DB");
    	}
    	
    }
    finally
    {
    	if(pstmt!=null)
    	{
    		pstmt.close();
    	}
    	if(con!=null){
    		con.close();
    		}
    }
    	
    }
    
    
}
