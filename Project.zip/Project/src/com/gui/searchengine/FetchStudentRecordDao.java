package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class FetchStudentRecordDao 
{
	static boolean success=false;
    private static FetchingResultDto marksList=null;
    public static ArrayList<Object> list=new ArrayList<>();
    
private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
	}
public static ArrayList<Object>  search() throws ClassNotFoundException, SQLException{
		StringBuilder sql = new StringBuilder("select * from examresult");
		Connection con = null;
		
		PreparedStatement pstmt = null;
	    ResultSet rs = null;
	
		boolean isFound = false;
		try
		{
			con = createConnection();
						
			
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			list.clear();			
		    while(rs.next()){
				isFound = true;
							
				success=true;	
				marksList=new FetchingResultDto();
				
				marksList.setUserid(rs.getDouble("userid"));
				marksList.setMarks(rs.getDouble("marks"));
				marksList.setSubject(rs.getString("subject"));
				System.out.println("record"+marksList.toString());
				list.add(marksList);
				
							
		    }
			if(!isFound){
				success=false;
			}
			
	}
		finally{
			if(rs!=null){
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
				}
				if(con!=null){
				con.close();
				}
		}
		return list;
	}
}
