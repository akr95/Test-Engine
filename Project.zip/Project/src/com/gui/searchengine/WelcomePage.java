package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;
import javax.swing.Timer;
import javax.swing.UIManager;

public class WelcomePage extends JWindow {

	private JLabel lblNewLabel1;
	private JLabel lblNewLabel2;
	private JLabel lblNewLabel3;
	private JLabel lblNewLabel4;
	JProgressBar progressBar = new JProgressBar();
	private Timer animationTimer = null;
	private Timer progressTimer = null;
	private int progressCounter = 1;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lblNewLabel;
	
	public WelcomePage() {
		getContentPane().setBackground(new Color(238, 232, 170));
		doProgress();
	
		setBounds(100, 100, 487, 340);
		getContentPane().setLayout(null);
		
		lblNewLabel1 = new JLabel("     WELCOME");
		lblNewLabel1.setForeground(UIManager.getColor("List.selectionBackground"));
		lblNewLabel1.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblNewLabel1.setBounds(110, 11, 272, 94);
		getContentPane().add(lblNewLabel1);
		
		lblNewLabel2 = new JLabel("");
		lblNewLabel2.setForeground(new Color(255, 0, 0));
		lblNewLabel2.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblNewLabel2.setBounds(67, 116, 384, 79);
		getContentPane().add(lblNewLabel2);
		
		lblNewLabel2.setText("  "+LoginDao.name);
		
		progressBar = new JProgressBar();
		progressBar.setBounds(67, 307, 384, 22);
		getContentPane().add(progressBar);
		
		lblNewLabel3 = new JLabel("READY FOR  ");
		lblNewLabel3.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel3.setBounds(67, 231, 156, 46);
		getContentPane().add(lblNewLabel3);
		
		lblNewLabel4 = new JLabel("");
		lblNewLabel4.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel4.setBounds(233, 231, 135, 46);
		getContentPane().add(lblNewLabel4);
		lblNewLabel4.setText(TestName.choose.toUpperCase());
		
		lblNewLabel = new JLabel("QUIZ");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel.setBounds(378, 231, 73, 46);
		getContentPane().add(lblNewLabel);
	}
	

	private void doProgress(){
		progressTimer = new Timer(20,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(progressCounter<progressBar.getMaximum()){
					progressBar.setValue(progressCounter);
					progressCounter++;
				}
				else
				{
					if(animationTimer!=null){
					animationTimer.stop();
					}
					if(progressTimer!=null){
					progressTimer.stop();
					}
					WelcomePage.this.setVisible(false);
					WelcomePage.this.dispose();
					
					if(TestName.choose.equalsIgnoreCase("corejava"))
					{
					CoreJavaQuestions frame = new CoreJavaQuestions();
					frame.setVisible(true);
					frame=null;
					}
					else if(TestName.choose.equalsIgnoreCase("mysql"))
					{
						SqlQuestions frame1 = new SqlQuestions();
						frame1.setVisible(true);
						frame1=null;
					}
					else
					{
					      DisplayQuestions display=new DisplayQuestions();
					      display.setVisible(true);
					}
					
					
				}
				
			}
		});
		progressTimer.start();
	}
}
