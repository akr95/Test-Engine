package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class LoginDao {
	//private static String userid;
	//private static String password;
	static boolean success=false;
	static String name;
	
	private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
	}
	static void search(double id ,  String password) throws ClassNotFoundException, SQLException{
		StringBuilder sql = new StringBuilder("select id , password, name from register");
		Connection con = null;
		PreparedStatement pstmt = null;
	    ResultSet rs = null;
		boolean isWhere = false;
		boolean isFound = false;
		try
		{
			con = createConnection();
			// Dynamic SQL
			if(id>0){
				sql = sql .append(" where id = ").append(id);
				isWhere = true;
			}
			
			if(password!=null && password.trim().length()>0){
				if(isWhere){
				sql = sql .append( " and password='").append(password).append("'");
				}
				else
				{
					sql = sql .append( " where password ='").append(password).append("'");
					isWhere = true;
				}
			}
			
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			
			
		    while(rs.next()){
				isFound = true;
				name=rs.getString("name");
				success=true;
				
			}
			if(!isFound){
				
				success=false;
			}
			
	}
		finally{
			if(rs!=null){
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
				}
				if(con!=null){
				con.close();
				}
		}
		
	}
	
}
