package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class QuestionsUpload extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private JPanel contentPane;
	private JTextField option1TextField;
	private JTextField option2TextField;
	private JTextField option3TextField;
	private JTextField option4TextField;
	private JTextField anserTextField;
	private JTextField idTextField;
	private JTextField examTextField;
	
	JTextArea questionTextArea;
	public static String examName;
	private int i;
	private String [] sizeCount;

	Questions questions=new Questions();
	 
	public static void main(String[] args) 
	{
		QuestionsUpload q=new QuestionsUpload();
		q.setVisible(true);
					
					
				
	}

	/**
	 * Create the frame.
	 */
	public QuestionsUpload() {
		getContentPane().setForeground(Color.BLACK);
		getContentPane().setFont(new Font("Arial Black", Font.PLAIN, 11));
		
		
				
		setResizable(false);
		setTitle("QUESTIONS UPLOAD");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 703, 527);
		getContentPane().setLayout(null);
		
		JLabel questionLabel = new JLabel("Questions");
		questionLabel.setFont(new Font("Arial", Font.BOLD, 15));
		questionLabel.setBounds(10, 62, 76, 33);
		getContentPane().add(questionLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(95, 62, 515, 55);
		getContentPane().add(scrollPane);
		
		questionTextArea = new JTextArea();
		scrollPane.setViewportView(questionTextArea);
		
		
		JLabel option1 = new JLabel("Option A");
		option1.setFont(new Font("Arial", Font.BOLD, 11));
		option1.setBounds(21, 152, 53, 20);
		getContentPane().add(option1);
		
		option1TextField = new JTextField();
		option1TextField.setBounds(95, 152, 515, 26);
		getContentPane().add(option1TextField);
		option1TextField.setColumns(10);
		
		
		JLabel lblOption = new JLabel("Option B");
		lblOption.setFont(new Font("Arial", Font.BOLD, 11));
		lblOption.setBounds(21, 202, 46, 14);
		getContentPane().add(lblOption);
		
		option2TextField = new JTextField();
		option2TextField.setBounds(95, 199, 515, 26);
		getContentPane().add(option2TextField);
		option2TextField.setColumns(10);
		
		
		JLabel lblOption_1 = new JLabel("Option C");
		lblOption_1.setFont(new Font("Arial", Font.BOLD, 11));
		lblOption_1.setBounds(21, 248, 65, 14);
		getContentPane().add(lblOption_1);
		
		option3TextField = new JTextField();
		option3TextField.setBounds(95, 248, 515, 26);
		getContentPane().add(option3TextField);
		option3TextField.setColumns(10);
		
		
		JLabel lblOption_2 = new JLabel("Option D");
		lblOption_2.setFont(new Font("Arial", Font.BOLD, 11));
		lblOption_2.setBounds(21, 297, 46, 14);
		getContentPane().add(lblOption_2);
		
		option4TextField = new JTextField();
		option4TextField.setBounds(95, 294, 515, 26);
		getContentPane().add(option4TextField);
		option4TextField.setColumns(10);
		
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() 
		
		{
			public void actionPerformed(ActionEvent arg0) {
				onSubmit();
 try 
	{
		DatabaseDao.insert(questions.getId(), questions.getQuestions(), questions.getOne(), questions.getTwo()	,questions.getThree(), questions.getFour(), questions.getResult(),examName);
		onClear();
		
	} 
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}			
				
			}
		});
		btnSubmit.setBackground(Color.GREEN);
		btnSubmit.setFont(new Font("Arial", Font.BOLD, 15));
		btnSubmit.setForeground(new Color(0, 128, 0));
		btnSubmit.setBounds(514, 395, 96, 36);
		getContentPane().add(btnSubmit);
		
		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setFont(new Font("Arial", Font.BOLD, 11));
		lblAnswer.setBounds(21, 347, 53, 14);
		getContentPane().add(lblAnswer);
		
		
		anserTextField = new JTextField();
		anserTextField.setBounds(96, 344, 514, 26);
		getContentPane().add(anserTextField);
		anserTextField.setColumns(10);
		
		
		JLabel lblId = new JLabel("Ques.ID");
		lblId.setFont(new Font("Arial", Font.BOLD, 15));
		lblId.setBounds(10, 26, 76, 20);
		getContentPane().add(lblId);
		
		idTextField = new JTextField();
		idTextField.setToolTipText("Question ID");
		idTextField.setText(" 0");
		idTextField.setBounds(95, 27, 92, 20);
		getContentPane().add(idTextField);
		idTextField.setColumns(10);
		
		JLabel lblExamName = new JLabel("Table Name");
		lblExamName.setFont(new Font("Arial", Font.BOLD, 15));
		lblExamName.setBounds(265, 30, 101, 21);
		getContentPane().add(lblExamName);
		
		examTextField = new JTextField();
		examTextField.setBounds(367, 27, 142, 24);
		getContentPane().add(examTextField);
		examTextField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("*  Database name And Exam Name must be Same without any space ");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(262, 5, 362, 14);
		getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Clear");
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 16));
		btnNewButton.setBounds(346, 396, 96, 36);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("X");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				AdminLogin frame = new AdminLogin();
				frame.setVisible(true);
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("Arial Black", Font.BOLD, 13));
		btnNewButton_1.setBounds(634, 5, 53, 33);
		getContentPane().add(btnNewButton_1);
     	
	}
	
	void onSubmit()
	{
		examName=examTextField.getText().toLowerCase().trim();
		sizeCount=examName.split(" ");
		if(sizeCount.length>=1)
		{
			for (i=0;i<sizeCount.length-1;i++){
			sizeCount[0]+=sizeCount[i+1];
			}
			examName=sizeCount[0];
			System.out.println("e"+examName);
		}
		questions.setId(Integer.parseInt(idTextField.getText().trim()));
		questions.setQuestions(questionTextArea.getText());
		questions.setOne(option1TextField.getText());
		questions.setTwo(option2TextField.getText());
		questions.setThree(option3TextField.getText());
		questions.setFour(option4TextField.getText());
		questions.setResult(anserTextField.getText());
	}
	void onClear()
	{
		idTextField.setText("");
		questionTextArea.setText("");
		option1TextField.setText("");
		option2TextField.setText("");
		option3TextField.setText("");
		option4TextField.setText("");
		anserTextField.setText("");
	}
	
	
}
