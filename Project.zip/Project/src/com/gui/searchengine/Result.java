package com.gui.searchengine;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jfree.ui.RefineryUtilities;

public class Result extends JFrame 
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static double marks;
	private  JLabel lblbtn3;
	private  JLabel lblNewLabel;
	private  Icon icon;
	private  Icon icon1;
	private JLabel lblNewLabel1;
	private float calculation;
	private  JLabel lblNewLabel2;
	private JButton btnpiechart1;
	private double userID;
	private String subject;
		
	public Result() throws ClassNotFoundException, SQLException 
	{
		setTitle("RESULT");
		icon=new ImageIcon(Login.class.getResource("happy.png"));
		icon1=new ImageIcon(Login.class.getResource("sad.jpg"));
		
		subject=TestName.choose;
		System.out.println("subject"+subject);		
				
				
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 825, 470);
		getContentPane().setLayout(null);
		
		JLabel lblbtn1 = new JLabel("Dear Student");
		lblbtn1.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblbtn1.setBounds(23, 36, 132, 38);
		getContentPane().add(lblbtn1);
		
		JLabel lblbtn2 = new JLabel("YOUR SCORE IS =");
		lblbtn2.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblbtn2.setBounds(83, 85, 180, 38);
		getContentPane().add(lblbtn2);
		
		lblbtn3 = new JLabel("");
		lblbtn3.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblbtn3.setBounds(259, 85, 63, 38);
		getContentPane().add(lblbtn3);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnNewButton.setBounds(696, 295, 103, 50);
		getContentPane().add(btnNewButton);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(10, 124, 337, 258);
		getContentPane().add(lblNewLabel);
		
		lblNewLabel1 = new JLabel("");
		lblNewLabel1.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblNewLabel1.setBounds(20, 389, 388, 24);
		getContentPane().add(lblNewLabel1);
		
		lblNewLabel2 = new JLabel("");
		lblNewLabel2.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblNewLabel2.setBounds(409, 389, 84, 31);
		getContentPane().add(lblNewLabel2);
		
		btnpiechart1 = new JButton("Show PieChart");
		btnpiechart1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 PieChart demo;
				try {
					demo = new PieChart( "Exam Quiz" );
					demo.setSize( 560 , 367 );    
				    RefineryUtilities.centerFrameOnScreen(demo);    
				    demo.setVisible( true ); 
				    demo=null;
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}  
			      
				
			}
		});
		btnpiechart1.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnpiechart1.setBounds(376, 295, 188, 50);
		getContentPane().add(btnpiechart1);
		
		JButton btnNewButton_1 = new JButton("Create PieChart Image");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PieChart3D piechart3d=new PieChart3D();
				try {
					piechart3d.createImages();
					piechart3d=null;
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnNewButton_1.setBounds(505, 214, 266, 50);
		getContentPane().add(btnNewButton_1);
	    
		
    if(TestName.choose.equalsIgnoreCase("corejava")){
    	showCoreresult();
      }
    else  if(TestName.choose.equalsIgnoreCase("mysql"))
    {
    	showSqlresult();
    }
    else {
    	
    	showExamResult();
      }		
		
  }
	
private void showCoreresult(){
	
		marks= CoreJavaQuestions.resultMatching();
	    userID=Login.id;
	    try {
			StoreResultInDB.insert(userID, marks, subject);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		lblbtn3.setText(String.valueOf(marks));
		if(marks>4){
			lblNewLabel.setIcon(icon);
			calculation=(float) ((marks/10)*100);
			lblNewLabel1.setText("CONGRALUATIONS ! YOU GOT");
			lblNewLabel2.setText(String.valueOf(calculation)+"%");
		}
		else{
			lblNewLabel.setIcon(icon1);
			calculation=(float) ((marks/10)*100);
			lblNewLabel1.setText("Try Again! YOU GOT");
			lblNewLabel2.setText(String.valueOf(calculation)+"%");
		}
		
	}


private void showSqlresult(){
	
	marks= SqlQuestions.resultMatching();
	userID=Login.id;
    try {
		StoreResultInDB.insert(userID, marks, subject);
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	lblbtn3.setText(String.valueOf(marks));
	if(marks>4){
		lblNewLabel.setIcon(icon);
		calculation=(float) ((marks/10)*100);
		lblNewLabel1.setText("CONGRALUATIONS ! YOU GOT");
		lblNewLabel2.setText(String.valueOf(calculation)+"%");
	}
	else
	{
		lblNewLabel.setIcon(icon1);
		calculation=(float) ((marks/10)*100);
		lblNewLabel1.setText("Try Again! YOU GOT");
		lblNewLabel2.setText(String.valueOf(calculation)+"%");
	}
	
 }


private void showExamResult()
   {
	marks= DisplayQuestions.resultMatching();
	userID=Login.id;
    try {
		StoreResultInDB.insert(userID, marks, subject);
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	lblbtn3.setText(String.valueOf(marks));
	if(marks>4){
		lblNewLabel.setIcon(icon);
		calculation=(float) ((marks/10)*100);
		lblNewLabel1.setText("CONGRALUATIONS ! YOU GOT");
		lblNewLabel2.setText(String.valueOf(calculation)+"%");
	}
	else
	{
		lblNewLabel.setIcon(icon1);
		calculation=(float) ((marks/10)*100);
		lblNewLabel1.setText("Try Again! YOU GOT");
		lblNewLabel2.setText(String.valueOf(calculation)+"%");
	}
   }
 }



	


