package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class CreateDatabaseTable extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private JTextField textField;
	String examName;
	private String[] sizeCount;
	private int i;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
				CreateDatabaseTable frame = new CreateDatabaseTable();
				frame.setVisible(true);
				
	}

	/**
	 * Create the frame.
	 */
	public CreateDatabaseTable()
	{
		setResizable(false);
		setTitle("Create Table");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 517, 300);
		getContentPane().setLayout(null);
		
		JLabel lblTableForStore = new JLabel("Table For Store Questions");
		lblTableForStore.setFont(new Font("Arial", Font.BOLD, 15));
		lblTableForStore.setBounds(38, 64, 205, 32);
		getContentPane().add(lblTableForStore);
		
		textField = new JTextField();
		textField.setBounds(253, 71, 152, 32);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnCreate = new JButton("CreateDB");
		btnCreate.setForeground(Color.BLUE);
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				examName=textField.getText().toLowerCase().trim();
				sizeCount=examName.split(" ");
				if(sizeCount.length>=1)
				{
					for (i=0;i<sizeCount.length-1;i++){
					sizeCount[0]+=sizeCount[i+1];
					}
					examName=sizeCount[0];
					System.out.println("e"+examName);
				}
				try {
					CreateDBForQuestions .create(examName);
					textField.setText("");
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnCreate.setFont(new Font("Arial", Font.BOLD, 15));
		btnCreate.setBounds(235, 126, 112, 32);
		getContentPane().add(btnCreate);
		
		JLabel lblDatabaseName = new JLabel("*  Database name And Exam Name must be Same without any space ");
		lblDatabaseName.setForeground(Color.RED);
		lblDatabaseName.setBounds(38, 39, 426, 14);
		getContentPane().add(lblDatabaseName);
		
		JButton btnNewButton = new JButton("Clear");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 15));
		btnNewButton.setBounds(85, 126, 103, 32);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				setVisible(false);
				AdminLogin frame = new AdminLogin();
				frame.setVisible(true);
			
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 15));
		btnNewButton_1.setBounds(377, 126, 103, 32);
		getContentPane().add(btnNewButton_1);
	}
}
