package com.gui.searchengine;

public class FetchingResultDto 
{
          private double userid;
          private double marks;
          private String subject;
		public double getUserid() {
			return userid;
		}
		public void setUserid(double userid) {
			this.userid = userid;
		}
		public double getMarks() {
			return marks;
		}
		public void setMarks(double marks) {
			this.marks = marks;
		}
		public String getSubject() {
			return subject;
		}
		public void setSubject(String string) {
			this.subject = string;
		}
		@Override
		public String toString() {
			return "FetchingResultDto [userid=" + userid + ", marks=" + marks
					+ ", subject=" + subject + "]";
		}
          
}
