package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FetchPassStudentRecord extends JFrame {

	private static final long serialVersionUID = 1L;
    private	ArrayList<Object> arraylist=new ArrayList<>();
	private  double userid;
	private double marks;
	private String subject;
	private FetchingResultDto marksRecord;
	private JTable table;
	private String[] columnNames={"Userid","Marks","Subject"};

	
	public static void main(String[] args) 
	{
		
					FetchPassStudentRecord frame = new FetchPassStudentRecord();
					frame.setVisible(true);
				
	}

	
	
	public FetchPassStudentRecord() 
	{
		setResizable(false);
		setTitle("Student Marks");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
	
		try 
		{
			
			arraylist=FetchStudentRecordDao.search();
		} 
		catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	
		DefaultTableModel model = new DefaultTableModel();
	    model.setColumnIdentifiers(columnNames);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(75, 62, 290, 188);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		   table.setModel(model);
	        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
	        table.setFillsViewportHeight(true);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
		    	setVisible(false);
				AdminLogin frame = new AdminLogin();
				frame.setVisible(true);
				
			}
		});
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 12));
		btnNewButton.setBounds(378, 5, 46, 27);
		getContentPane().add(btnNewButton);
		System.out.println(arraylist.size());
		for(int i=0;i<arraylist.size();i++)
		{
			
			marksRecord=(FetchingResultDto) arraylist.get(i);
			userid=marksRecord.getUserid();
			marks=marksRecord.getMarks();
			subject=marksRecord.getSubject();
	
		    model.addRow(new Object[]{userid, marks, subject});
		
			
		}
		
	}	
  }
