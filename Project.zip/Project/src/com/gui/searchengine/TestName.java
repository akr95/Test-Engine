package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TestName extends JFrame {

	static String choose;
	SimpleDateFormat sdf;
	Date dateWithoutTime ;
	String examNameFromDB;
	String dateOfExamFromDB;
	JButton examPaperBtn;
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

    public static void main(String[] args) 
    {
	 
    	TestName ad=new TestName();
    	ad.setVisible(true);
	
   }
    
    public TestName()
{
		setTitle("QUIZ");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		
		
		JLabel lblExaminationQuiz = new JLabel("PROGRAMMING  QUIZ");
		lblExaminationQuiz.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblExaminationQuiz.setBounds(101, 17, 275, 66);
		getContentPane().add(lblExaminationQuiz);
		
		JButton btnButton1 = new JButton("CORE JAVA QUIZ");
		btnButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
							
			setVisible(false);
			choose="corejava";
			WelcomePage wel=new WelcomePage();
			wel.setVisible(true);
			wel=null;
			}
		});
		btnButton1.setForeground(Color.BLUE);
		btnButton1.setFont(new Font("Arial Black", Font.BOLD, 16));
		btnButton1.setBounds(116, 153, 231, 40);
		getContentPane().add(btnButton1);
		
		JButton btnNewButton = new JButton("  MYSQL QUIZ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				choose="mysql";
				setVisible(false);
				
				WelcomePage wel=new WelcomePage();
				wel.setVisible(true);
				wel=null;
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 16));
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setBounds(116, 94, 231, 40);
		getContentPane().add(btnNewButton);
		
        examPaperBtn = new JButton("");
		examPaperBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				choose=examNameFromDB;
				setVisible(false);
				
				WelcomePage wel=new WelcomePage();
				wel.setVisible(true);
				wel=null;
				
				
			}
		});
		examPaperBtn.setFont(new Font("Arial Black", Font.BOLD, 16));
		examPaperBtn.setForeground(Color.BLUE);
		examPaperBtn.setBounds(116, 204, 231, 40);
		getContentPane().add(examPaperBtn);
		
		
    try {
			
			getExamDateFromDB();    //call date method
			
		} catch (ParseException e1) {
			
			e1.printStackTrace();
		} 
		
		
	}
		
		void getExamDateFromDB() throws ParseException
		{
      //      sdf = new SimpleDateFormat("dd-MM-yyyy");      
		//    dateWithoutTime = sdf.parse(sdf.format(new Date()));
			Date date=new Date(System.currentTimeMillis());
		    System.out.println("date"+date.toString());
		   try
		 {
			FetchExamSchedule.search(date.toString());
			examNameFromDB=FetchExamSchedule.examNameFromDB;
			dateOfExamFromDB=FetchExamSchedule.dateOfExamFromDB;
			if(date.toString().equals(dateOfExamFromDB))
			{
				System.out.println("date match");
				System.out.println("examname"+examNameFromDB);
				examPaperBtn.setText(examNameFromDB);
			}
		 } catch (ClassNotFoundException | SQLException e) 
		   {
			
			e.printStackTrace();
		}
		}
}
