package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class AdminLoginWindow extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private JPanel contentPane;
	private JTextField loginIDTextField;
	private JLabel lblNewLabel;
	private JButton btnNewButton;
	private JPasswordField passwordTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					
	}

	/**
	 * Create the frame.
	 */
	public AdminLoginWindow() {
		setResizable(false);
		setTitle("Admin Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblLoginid = new JLabel("Login ID");
		lblLoginid.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblLoginid.setBounds(45, 56, 103, 24);
		getContentPane().add(lblLoginid);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblPassword.setBounds(45, 91, 103, 33);
		getContentPane().add(lblPassword);
		
		loginIDTextField = new JTextField();
		loginIDTextField.setToolTipText("Enter Login ID");
		loginIDTextField.setBounds(178, 60, 197, 20);
		getContentPane().add(loginIDTextField);
		loginIDTextField.setColumns(10);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
		if(loginIDTextField.getText().equals("admin") && passwordTextField.getText().equals("admin"))
		{
				setVisible(false);				
				AdminLogin frame = new AdminLogin();
				frame.setVisible(true);
		}
		else
		{
			lblNewLabel.setText("enter valid Email Id");
			loginIDTextField.setText("");
			passwordTextField.setText("");
		}
	}
		});
		btnSubmit.setForeground(Color.BLUE);
		btnSubmit.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnSubmit.setBounds(304, 149, 111, 45);
		getContentPane().add(btnSubmit);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(161, 11, 214, 34);
		getContentPane().add(lblNewLabel);
		
		btnNewButton = new JButton("Clear");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				passwordTextField.setText("");
				loginIDTextField.setText("");
			}
		});
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 15));
		btnNewButton.setBounds(96, 149, 111, 45);
		getContentPane().add(btnNewButton);
		
		passwordTextField = new JPasswordField();
		passwordTextField.setBounds(178, 99, 197, 20);
		getContentPane().add(passwordTextField);
	}
}
