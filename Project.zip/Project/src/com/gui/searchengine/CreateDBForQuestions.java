package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

class CreateDBForQuestions 
{
        	
	private static Connection createConnection() throws ClassNotFoundException, SQLException 
        {
			ResourceBundle rb = ResourceBundle.getBundle("path");
			Class.forName(rb.getString("drivername"));
			Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
			return con;
        }
	
   static void create(String name) throws ClassNotFoundException, SQLException
	{
		
	    String sql = "CREATE TABLE "+name+"(id INT NOT NULL,question VARCHAR(500) NOT NULL,one VARCHAR(300) NOT NULL,two VARCHAR(300) NOT NULL,three VARCHAR(300),four VARCHAR(300),result VARCHAR(20) NOT NULL,PRIMARY KEY (id))";
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean recordAdded =false;
		try
		{
			con = createConnection();  // Connection 
			pstmt = con.prepareStatement(sql); 
			recordAdded = pstmt.execute();
			recordAdded =true;
			if(recordAdded==true)
			{
				System.out.println("create DB");
			}
			else
			{
				System.out.println("not create DB");
			}
			
		}
		finally{
			if(pstmt!=null){
			pstmt.close();
			}
			if(con!=null){
			con.close();
			}
		}
	   
	   
	   
	}
}
