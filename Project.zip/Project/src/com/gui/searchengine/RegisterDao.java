package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
//import java.util.ResourceBundle;
import java.util.ResourceBundle;


public class RegisterDao {

	private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
	}
	static void insert(double id, String name, String email, String password, String country) throws ClassNotFoundException, SQLException{
		String sql = "insert into register (id,name,email,password,country) values(?,?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		int recordAdded = 0;
		try
		{
			con = createConnection();  // Connection 
			pstmt = con.prepareStatement(sql);  // Query
			pstmt.setDouble(1, id);
			pstmt.setString(2, name);  // Query Values Assign
			pstmt.setString(3, email);
			pstmt.setString(4, password);
			pstmt.setString(5, country);
			recordAdded = pstmt.executeUpdate();  // Query Fire
			if(recordAdded>0){
				System.out.println("Record Added in DB");
			}
			else
			{
				System.out.println("Not Added....");
			}
		}
		finally{
			if(pstmt!=null){
			pstmt.close();
			}
			if(con!=null){
			con.close();
			}
		}
	}
	
	/*
	public static void main(String[] args) {
		
		System.out.println("Enter the Name");
		String name = new Scanner(System.in).next();
		System.out.println("Enter the Name");
		String email = new Scanner(System.in).next();
			//System.out.println("Enter the Name");
			System.out.println("Enter the Name");
			String password = new Scanner(System.in).next();
			System.out.println("Enter the Name");
			String country = new Scanner(System.in).next();
			
			try {
				insert(name, email, password, country);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	

	}*/
}
