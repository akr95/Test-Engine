package com.gui.searchengine;

import java.sql.SQLException;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
 
@SuppressWarnings("serial")
public class PieChart extends ApplicationFrame 
{
	private static int rightQuestions;
	private static int wrongQuestions;
	private static int attemptedQuestions;
	private static int  notAttemptedQuestions;
	/*ArrayList<?> customList=new ArrayList<>();
	private int listsize;*/
	
   public PieChart( String title ) throws ClassNotFoundException, SQLException 
   {
	   super( title );
	   rightQuestions=(int) Result.marks;
    if(TestName.choose.equalsIgnoreCase("corejava"))
	   {
	   attemptedQuestions=CoreJavaQuestions.attemptQuestions;
   }
	   else if(TestName.choose.equalsIgnoreCase("mysql"))
   {
		   attemptedQuestions=SqlQuestions.attemptQuestions;   
   }
   else{
	   attemptedQuestions=DisplayQuestions.attemptQuestions;
   }
	   wrongQuestions=(int) (attemptedQuestions-rightQuestions);
	  /* new RetrieveDataDao();
	   customList=RetrieveDataDao.search();
	   listsize=customList.size();
	   System.out.println("listsize"+listsize);*/
	   notAttemptedQuestions=10-attemptedQuestions;
	   setContentPane(createDemoPanel( ));
   }
   
     
   private static PieDataset createDataset( ) 
   {
      DefaultPieDataset dataset = new DefaultPieDataset( );
      dataset.setValue( "Right Questions" , new Double( rightQuestions ) );  
      dataset.setValue( "Wrong Questions" , new Double( wrongQuestions ) );   
      dataset.setValue( "Not Attempted" , new Double( notAttemptedQuestions) );    
      dataset.setValue( "Attempted Questions" , new Double( attemptedQuestions ) );  
      return dataset;         
   }
   private static JFreeChart createChart( PieDataset dataset )
   {
      JFreeChart chart = ChartFactory.createPieChart(      
         "Result In Graph",  // chart title 
         dataset,        // data  view  
         true,           // include legend   
         true, 
         false);

      return chart;
   }
   public static JPanel createDemoPanel( )
   {
      JFreeChart chart = createChart(createDataset( ) );  
      return new ChartPanel( chart ); 
   }
 
}