package com.gui.searchengine;

import java.io.*; 

import org.jfree.chart.ChartFactory; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PiePlot3D; 
import org.jfree.data.general.DefaultPieDataset; 
import org.jfree.chart.ChartUtilities;

public class PieChart3D {

	private static int rightQuestions;
	private static int wrongQuestions;
	private static int attemptedQuestions;
	private static int  notAttemptedQuestions;
	
     void createImages() throws IOException
   {
	   rightQuestions=(int) Result.marks;
	   if(TestName.choose.equalsIgnoreCase("corejava"))
	   {
	      attemptedQuestions=CoreJavaQuestions.attemptQuestions;
	   }
	   else if(TestName.choose.equalsIgnoreCase("mysql"))
	   {
		   attemptedQuestions=SqlQuestions.attemptQuestions;
	   }
	   else
	   {
		   attemptedQuestions=DisplayQuestions.attemptQuestions;
	   }
	   wrongQuestions=(int) (attemptedQuestions-rightQuestions);
	   notAttemptedQuestions=10-attemptedQuestions;
	   
	   
      DefaultPieDataset dataset = new DefaultPieDataset( );             
      dataset.setValue( "Right Questions "+rightQuestions  , new Double( rightQuestions ) );  
      dataset.setValue( "Wrong Questions "+ wrongQuestions  , new Double( wrongQuestions ) );   
      dataset.setValue( "Not Attempted "+notAttemptedQuestions  , new Double( notAttemptedQuestions) );    
      dataset.setValue( "Attempted Questions "+attemptedQuestions , new Double( attemptedQuestions ) );  

      JFreeChart chart = ChartFactory.createPieChart3D( 
         "Result In Graph" ,  // chart title                   
         dataset ,         // data 
         true ,            // include legend                   
         true, 
         false);

      final PiePlot3D plot = ( PiePlot3D ) chart.getPlot( );             
      plot.setStartAngle( 270 );             
      plot.setForegroundAlpha( 0.60f );             
      plot.setInteriorGap( 0.02 );             
      int width = 640; /* Width of the image */             
      int height = 480; /* Height of the image */                             
      File pieChart3D = new File( "C://Users//AKSHAY KUMAR//Desktop//pie_Chart3D.jpeg" );
       ChartUtilities.saveChartAsJPEG( pieChart3D , chart , width , height );   
   }
}
