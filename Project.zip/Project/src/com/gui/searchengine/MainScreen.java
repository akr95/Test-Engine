package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.Timer;


public class MainScreen extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ImageIcon icon =new ImageIcon(MainScreen.class.getResource("logo.jpg"));
	StringBuilder sb = new StringBuilder("Exam Quiz");
	Timer titleTimer = null;
	int counter = 1;
	int length  = 0;
	private void fillSpace(int spaceValue){
		for(int i = 1 ; i<=spaceValue; i++){
			sb.insert(0, " ");
		}
	}
	void moveTitle(){
		fillSpace(150);
		length = sb.length();
		titleTimer = new Timer(100, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(counter<=length){
					MainScreen.this.setTitle(sb.toString());
					sb.deleteCharAt(0);
					counter++;
				}
				else
				{
					counter = 1;
					sb = new StringBuilder("EXAM QUIZ");
					fillSpace(150);
					
				}
				
			}
		});
		titleTimer.start();
	}
	public static void main(String[] args) {
		
					MainScreen frame = new MainScreen();
					frame.setVisible(true);
					frame.moveTitle();
				
	}

	/**
	 * Create the frame.
	 */
	public MainScreen() {
		//setResizable(false);
		setFont(new Font("Arial Black", Font.BOLD, 18));
		setTitle("EXAM QUIZ");
	 	setForeground(Color.CYAN);
		setIconImage(icon.getImage());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		

		JMenu adminLogin = new JMenu("Admin");
		adminLogin.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		menuBar.add(adminLogin);
		
		JMenuItem adminLoginBtn = new JMenuItem("Admin Login");
		adminLoginBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				
				AdminLoginWindow frame = new AdminLoginWindow();
			    frame.setVisible(true);
				
			}
		});
		adminLoginBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		adminLogin.add(adminLoginBtn);
		
		
		adminLogin.addSeparator();
		
		JMenuItem adminExitBtn = new JMenuItem("Exit");
		adminLogin.add(adminExitBtn);
		
		
		
		
		JMenu mnAdmin = new JMenu("Students");
		menuBar.add(mnAdmin);
		
		JMenuItem mntmLogin = new JMenuItem("Login");
		mntmLogin.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		mntmLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Login loginframe = new Login();	
				loginframe.setVisible(true);
				loginframe=null;
			}
		});
		mnAdmin.add(mntmLogin);
		
		JMenuItem mntmRegister = new JMenuItem("Register");
		mntmRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Registration registerframe = new Registration();
				 
				 registerframe.setVisible(true);
				registerframe=null;
			}
		});
		mnAdmin.add(mntmRegister);
		mnAdmin.addSeparator();
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnAdmin.add(mntmExit);
		//menuBar.setBounds(77, 10, 200, 50);
		//getContentPane().add(menuBar);
	    setExtendedState(JFrame.MAXIMIZED_BOTH);
		getContentPane().setLayout(null);
	}
}
