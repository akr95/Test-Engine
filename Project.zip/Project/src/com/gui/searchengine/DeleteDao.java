package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

class DeleteDao{

	private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
		}
		
static void delete (int id ) throws ClassNotFoundException, SQLException{
	String sql = "delete from sqlquestions where id =?";
	Connection con = null;
	PreparedStatement pstmt = null;
	int recordDeleted = 0;
	try
	{
		con = createConnection();
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		//pstmt.setString(2,name);
		//pstmt.setDouble(3, salary);
		recordDeleted = pstmt.executeUpdate();
		if(recordDeleted>0){
			System.out.println("Record Deleted in DB");
		}
		else
		{
			System.out.println("Not Deleted....");
		}
	}
	finally{
		if(pstmt!=null){
		pstmt.close();
		}
		if(con!=null){
		con.close();
		}
	   }
	}
  

}