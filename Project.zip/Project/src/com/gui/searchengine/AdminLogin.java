package com.gui.searchengine;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;

import java.awt.Color;
import java.sql.Date;
import java.sql.SQLException;

@SuppressWarnings("serial")
public class AdminLogin extends JFrame {
	private JTextField textField;
	private JTextField dateTextField;
    public int dateCounter;
    private  JLabel errorLabel;
    private String examName;
    private int i;
    private String[] sizeCount;
   
//	private JPanel contentPane;

    public static void main(String[] args) 
    {
	 
    	AdminLogin ad=new AdminLogin();
    	ad.setVisible(true);
	
   }
    
	public AdminLogin() 
	{
		setResizable(false);
		setTitle("ADMIN ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 300);
		getContentPane().setLayout(null);
		
		JButton questionBtn = new JButton("Questions Upload");
		questionBtn.setForeground(Color.BLUE);
		questionBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				QuestionsUpload frameQuestionsUpload = new QuestionsUpload();
				frameQuestionsUpload.setVisible(true);
				AdminLogin.this.dispose();
			}
		});
		questionBtn.setBounds(10, 53, 144, 34);
		getContentPane().add(questionBtn);
		
		JButton totalStudentsBtn = new JButton("Students Marks List");
		totalStudentsBtn.setForeground(Color.BLUE);
		totalStudentsBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
			
				setVisible(false);
				FetchPassStudentRecord frame = new FetchPassStudentRecord();
				frame.setVisible(true);
							
			}
		});
		totalStudentsBtn.setBounds(178, 53, 157, 34);
		getContentPane().add(totalStudentsBtn);
		
		JLabel lblEnterNameOf = new JLabel("Enter Name Of Exam ");
		lblEnterNameOf.setFont(new Font("Arial", Font.PLAIN, 15));
		lblEnterNameOf.setBounds(63, 126, 144, 25);
		getContentPane().add(lblEnterNameOf);
		
		textField = new JTextField();
		textField.setBounds(232, 126, 133, 23);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblDate = new JLabel("Date Of Exam");
		lblDate.setFont(new Font("Arial", Font.PLAIN, 15));
		lblDate.setBounds(63, 162, 144, 20);
		getContentPane().add(lblDate);
		
		dateTextField = new JTextField();
		dateTextField.setBounds(231, 160, 133, 20);
		getContentPane().add(dateTextField);
		dateTextField.setColumns(10);
		
		JLabel lblDd = new JLabel("DD");
		lblDd.setBounds(316, 191, 20, 14);
		getContentPane().add(lblDd);
		
		JLabel lblMm = new JLabel(" MM");
		lblMm.setBounds(278, 191, 28, 14);
		getContentPane().add(lblMm);
		
		JLabel lblYyyy = new JLabel(" YYYY");
		lblYyyy.setBounds(232, 191, 36, 14);
		getContentPane().add(lblYyyy);
		
		JButton btnSubmitExamDetail = new JButton("Submit Exam Detail");
		btnSubmitExamDetail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				validateField();
				if(dateCounter==4)
				{
		
					try 
					{
						ExamScheduleSave.insert(examName, dateTextField.getText());
						textField.setText("");
						dateTextField.setText("");
						errorLabel.setText("");
						System.out.println("add data");
						
					} catch (ClassNotFoundException | SQLException e) {
						e.printStackTrace();
					}
				}
				else
				{
					textField.setText("");
					dateTextField.setText("");
					errorLabel.setText("enter valid data");
				}
			}
		});
		btnSubmitExamDetail.setForeground(Color.BLUE);
		btnSubmitExamDetail.setBounds(274, 216, 144, 34);
		getContentPane().add(btnSubmitExamDetail);
		
        errorLabel = new JLabel("");
		errorLabel.setBounds(389, 160, 93, 22);
		getContentPane().add(errorLabel);
		
		JLabel label = new JLabel("-");
		label.setBounds(304, 191, 20, 14);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("-");
		label_1.setBounds(265, 191, 13, 14);
		getContentPane().add(label_1);
		
		JButton btnNewButton = new JButton("Create DB Table");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				CreateDatabaseTable frame = new CreateDatabaseTable();
				frame.setVisible(true);
				
			}
		});
		btnNewButton.setBounds(359, 53, 151, 34);
		getContentPane().add(btnNewButton);
		
	}
	
	 void validateField()
	{	
		 dateCounter=0;
		 
		 String systemDate=new Date(System.currentTimeMillis()).toString();
		 String[] systemDateCheck=systemDate.split("-");
		 
		 
		if(dateTextField.getText()!=null && textField.getText()!=null)
	{ 
			examName=textField.getText().toLowerCase().trim();
			sizeCount=examName.split(" ");
			if(sizeCount.length>=1)
			{
				for (i=0;i<sizeCount.length-1;i++){
				sizeCount[0]+=sizeCount[i+1];
				}
				examName=sizeCount[0];
				System.out.println("e"+examName);
			}
					
	    String date =dateTextField.getText();
	    
	    String[] dateCheck=date.split("-");
	   
	    if(dateCheck[2].length()==2 &&Integer.parseInt(dateCheck[2])<=31)
	    {
	    	dateCounter++;
	    }
	    if(dateCheck[1].length()==2 && Integer.parseInt(dateCheck[1])<=12)
	    {
	    	dateCounter++;
	    }
	    if(dateCheck[0].length()==4 && Integer.parseInt(dateCheck[0])>=2016)
	    {
	    	dateCounter++;
	    }
	   if(Integer.parseInt(systemDateCheck[0])<=Integer.parseInt(dateCheck[0])&&Integer.parseInt(systemDateCheck[1])<=Integer.parseInt(dateCheck[1])&&Integer.parseInt(systemDateCheck[2])<=Integer.parseInt(dateCheck[2]))
	   {
		   System.out.println("system date "+systemDate);
		   System.out.println("enter date "+date);
		   dateCounter++; 
	   }
	  
	    
	 }
		else
		{
			dateTextField.setText("enter Valid date");
			textField.setText("");
			dateTextField.setText("");
		}
	}
}
