package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class FetchExamSchedule
{
	public static String dateOfExamFromDB;
	public static String examNameFromDB;
          
	private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
	}
public static void search(String date) throws ClassNotFoundException, SQLException{
		StringBuilder sql = new StringBuilder("select * from examschedule");
		Connection con = null;
		
		PreparedStatement pstmt = null;
	    ResultSet rs = null;
    //	System.out.println("d"+date);
		boolean isFound = false;
		try
		{
			con = createConnection();
			sql = sql .append(" where dateOfexam = '").append(date).append("'");			
			
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
						
		    while(rs.next())
		    {
				 examNameFromDB=rs.getString("examName");
				 dateOfExamFromDB=rs.getString("dateOfexam");
				 isFound = true;				
		    }
			if(!isFound){
				System.out.println("not found");
			}
			
	}
		finally{
			if(rs!=null){
				rs.close();
			}
			if(pstmt!=null){
				pstmt.close();
				}
				if(con!=null){
				con.close();
				}
		}
//		return list;
	}
	
}
