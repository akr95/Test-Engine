package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ExamScheduleSave {
	
    	private static Connection createConnection() throws ClassNotFoundException, SQLException
    {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
 }
    	
 static void insert(String examName,String dateOfexam) throws ClassNotFoundException, SQLException{
	String sql = "insert into examschedule (examName,dateOfexam) values(?,?)";
	Connection con = null;
	PreparedStatement pstmt = null;
	int recordAdded = 0;
	try
	{
		con = createConnection();  // Connection 
		//stmt = con.createStatement(); // Query
		pstmt = con.prepareStatement(sql);  // Query
		pstmt.setString(1, examName);  // Query Values Assign
		pstmt.setString(2, dateOfexam);
		recordAdded = pstmt.executeUpdate();  // Query Fire
		if(recordAdded>0){
		
			System.out.println("Record Added in DB");
		}
		else
		{
			System.out.println("Not Added....");
		}
	}
	finally{
		if(pstmt!=null){
		pstmt.close();
		}
		if(con!=null){
		con.close();
		}
	}
  }
 }
