package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField1;
	private JButton btLogin=null;
	private JPasswordField textField2;
	private JLabel lblLabel=null;
	public static double id;
	//private Icon icon1;

	public Login() {
		
	//	Icon icon=new ImageIcon(Login.class.getResource("login.png"));
	//	icon1=new ImageIcon(Login.class.getResource("loadicon.gif"));
		
		setResizable(false);
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 572, 321);
		getContentPane().setLayout(null);
		
		/*Icon image =new ImageIcon(Login.class.getResource("download.png"));
		getContentPane().setIcon(image);*/
		
		
		JLabel lblUserid = new JLabel("UserId");
		lblUserid.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblUserid.setBounds(96, 70, 87, 26);
		getContentPane().add(lblUserid);
		
		textField1 = new JTextField();
		textField1.setBounds(253, 73, 185, 26);
		getContentPane().add(textField1);
		textField1.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblPassword.setBounds(96, 141, 101, 26);
		getContentPane().add(lblPassword);
		
		btLogin = new JButton("LOGIN");
		btLogin.setForeground(Color.BLUE);
		btLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					loginDao();
					
				if(LoginDao.success)
					{
					setVisible(false);
					
					TestName frame = new TestName();
					frame.setVisible(true);
					Login.this.dispose();
				}
					else
					{
						JOptionPane.showMessageDialog(Login.this, "Enter correct UserId and Password");
						textField1.setText("");
						textField2.setText("");
  				}
					
					
				} catch (ClassNotFoundException | SQLException e1) {
				
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btLogin.setFont(new Font("Tahoma", Font.BOLD, 14));
		btLogin.setBounds(380, 233, 89, 33);
		getContentPane().add(btLogin);
		
		textField2 = new JPasswordField();
		textField2.setBounds(253, 144, 185, 26);
		getContentPane().add(textField2);
		
		lblLabel = new JLabel();
		//lblLabel.setIcon(icon);
		lblLabel.setForeground(Color.BLACK);
    	lblLabel.setBounds(10, 28, 173, 187);
		getContentPane().add(lblLabel);
		
		JButton btnNewButton = new JButton("CLEAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField1.setText("");
				textField2.setText("");
			}
		});
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 13));
		btnNewButton.setBounds(183, 233, 89, 33);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New User Register Here");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				Registration registration=new Registration();
				registration.setVisible(true);
				
			}
		});
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 13));
		lblNewLabel.setBounds(221, 181, 201, 28);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Login:");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 15));
		lblNewLabel_1.setBounds(31, 11, 87, 33);
		getContentPane().add(lblNewLabel_1);
	}
	
	void loginDao() throws ClassNotFoundException, SQLException
	{	
		 id=Double.parseDouble(textField1.getText());
		
		@SuppressWarnings("deprecation")
		String password=textField2.getText();
		
	
		try{
		
	    new LoginDao();
		LoginDao.search(id, password);
		//((AbstractButton) getContentPane()).setIcon(icon1);
		
		
	}
		catch(Exception e){
			e.printStackTrace();
			
		}
	}
}
