package com.gui.searchengine;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.Timer;


@SuppressWarnings("serial")
public class SplashScreen extends JWindow

{
	private Timer progressTimer = null;
	int color = 1;
	int x=50 ;
	int XCounter = 1;
	int progressCounter = 1;
	JProgressBar progressBar = new JProgressBar();
	private boolean isVisible = true;
	private Timer animationTimer = null;
	Icon icon = new ImageIcon(SplashScreen.class.getResource("exam.gif"));
	JLabel lblNewLabel = new JLabel("");
	JLabel lblNewLabel_1 = new JLabel("TEST ENGINE");
	
	public static void main(String[] args) {
		
					SplashScreen frame = new SplashScreen();
					frame.setVisible(true);
					frame.doAnimation();
					frame.doProgress();
					frame=null;
				
	}

	/**
	 * Create the frame.
	 */
	public SplashScreen() {
		getContentPane().setBackground(new Color(144, 238, 144));
		
		setBounds(100, 180, 418, 550);
		getContentPane().setLayout(null);
		setLocation(300, 200);
		
		
		lblNewLabel.setIcon(icon);
		lblNewLabel.setBounds(53, 59, 329, 419);
		getContentPane().add(lblNewLabel);
		lblNewLabel_1.setForeground(new Color(255, 69, 0));
		
		
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblNewLabel_1.setBounds(30, 11, 305, 26);
		getContentPane().add(lblNewLabel_1);
		
		
		progressBar.setBackground(Color.GRAY);
		progressBar.setForeground(Color.YELLOW);
		progressBar.setBounds(30, 489, 352, 50);
		getContentPane().add(progressBar);
		
	}
	
	private void doProgress(){
		progressTimer = new Timer(20,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(progressCounter<progressBar.getMaximum()){
					progressBar.setValue(progressCounter);
					progressCounter++;
				}
				else
				{
					if(animationTimer!=null){
					    animationTimer.stop();
					}
					if(progressTimer!=null){
					     progressTimer.stop();
					}
					SplashScreen.this.setVisible(false);
					SplashScreen.this.dispose();
					MainScreen obj = new MainScreen();
					obj.setVisible(true);
					obj.moveTitle();
					obj=null;
				}
				
			}
		});
		progressTimer.start();
	}
	
	private void doAnimation()
	{
		   
		animationTimer = new Timer(30,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				switch(color){
				case 1:
					lblNewLabel_1.setForeground(Color.RED);
					break;
				case 2:	
					lblNewLabel_1.setForeground(Color.GREEN);
					break;
				case 3:	
					lblNewLabel_1.setForeground(Color.CYAN);
					break;
				case 4:	
					lblNewLabel_1.setForeground(Color.YELLOW);
					break;
				default:
					lblNewLabel_1.setForeground(Color.BLACK);
					break;
				}
				if(color<=4){
				color++;
				}
				else
				{
					color = 1;
				}
				if(XCounter<=70)
				{
					lblNewLabel_1.setBounds(x, 0, 305, 90);
					x++;
					XCounter++;
				}
			else
				{
					XCounter = 1;
					x= 104;
				}
				lblNewLabel_1.setVisible(isVisible);
				isVisible = ! isVisible;
				
			}
		});
		animationTimer.start();
		
	}
}
 