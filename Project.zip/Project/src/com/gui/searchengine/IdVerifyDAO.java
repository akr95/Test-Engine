package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class IdVerifyDAO {
	private static boolean success=false;

	public static Connection createConnection() throws ClassNotFoundException, SQLException{
		ResourceBundle rb=ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con=DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
		
	}
	
	static boolean insert(double id) throws ClassNotFoundException, SQLException{
		StringBuffer sql=new StringBuffer("select id, email from register");
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		 success=false;
		try{
		con=createConnection();
		if(id>0){
			sql = sql .append(" where id = ").append(id);
			
		}
		pstmt=con.prepareStatement(sql.toString());
        rs=pstmt.executeQuery();
       
        while(rs.next()){
        	success=true;
        	       
        }
       
        return success;
	}
		finally{
			if(rs!=null){
			rs.close();}
			if(pstmt!=null){
        pstmt.close();}
			if(con!=null){
        con.close();}
		}
	}
	
	

}
