package com.gui.searchengine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

class DatabaseDao
 {
    	private static Connection createConnection() throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("path");
		Class.forName(rb.getString("drivername"));
		Connection con = DriverManager.getConnection(rb.getString("dburl"),rb.getString("userid"),rb.getString("password"));
		return con;
 }
    	
 static void insert(int id , String question, String one, String two, String three, String four ,String result,String examName) throws ClassNotFoundException, SQLException{
	String sql = "insert into "+examName+"(id,question,one,two,three,four,result) values(?,?,?,?,?,?,?)";
	Connection con = null;
	PreparedStatement pstmt = null;
	int recordAdded = 0;
	try
	{
		con = createConnection();  // Connection 
		//stmt = con.createStatement(); // Query
		// insert into employee(id,name,salary) values(1001,'Ram',9000);
		//int recordCount = stmt.executeUpdate("insert into employee(id,name,salary) values("+id+",'"+name+"',"+salary+")");		
		pstmt = con.prepareStatement(sql);  // Query
		pstmt.setInt(1, id);  // Query Values Assign
		pstmt.setString(2, question);
		pstmt.setString(3, one);
		pstmt.setString(4, two);
		pstmt.setString(5, three);
		pstmt.setString(6, four);
		pstmt.setString(7, result);
		recordAdded = pstmt.executeUpdate();  // Query Fire
		if(recordAdded>0){
			System.out.println("questions="+question);
			System.out.println("Record Added in DB");
		}
		else
		{
			System.out.println("Not Added....");
		}
	}
	finally{
		if(pstmt!=null){
		pstmt.close();
		}
		if(con!=null){
		con.close();
		}
	}
	
 }

}